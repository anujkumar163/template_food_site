from django.http import HttpResponse
from django.shortcuts import render

def webpage0(request):
	return render(request, "about.html")

def webpage1(request):
	return render(request, "blog.html")	

def webpage2(request):
	return render(request, "booking.html")

def webpage3(request):
	return render(request, "contact.html")	

def webpage4(request):
	return render(request, "feature.html")

def webpage5(request):
	return render(request, "index.html")

def webpage6(request):
	return render(request, "menu.html")	

def webpage7(request):
	return render(request, "single.html")

def webpage8(request):
	return render(request, "team.html")				